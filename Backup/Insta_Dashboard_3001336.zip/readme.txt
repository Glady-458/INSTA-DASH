#######################INSTABRAM DASHBOARD################################

ABOUT:
This project was aimed to make an application for an individual or business. In the business of all money, time is the most important asset of any organisation is to save them inefficient and cleverly will lead the org from making a profit as well as popularity
This application will help most organization, influencer and content creators to predict, how their account will progress and growth along the time. In this project enterprises, multi-million companies, etc. can use this extract data information for the commercial purpose. This application work as a third party where an organisation can gather information like count follower, followings, trends, tags, etc. this gathered information helps them to choose a suitable celebrity, person, individual for their advertising and marketing purpose. Even this help gather an audience and promote their product or services on a suitable page using trendy tags.

#######################LIBRARIES REQUEIRED################################

 COMMAND TO INSTALL::::::::

Pandas			: pip install pandas

Numpy			: pip install NumPy

Sklearn			: pip install scikit-learn

Matplotlib		: pip install matplotlib

Seaborn			: pip install seaborn

Xgboost			: pip install xgboost

Datetime		: pip install datetime

streamlit		: pip install streamlit

selenium		: pip install selenium

Scipy			: pip install scipy

json			: pip install jsonlib

BeautifulSoup		: pip install beautifulsoup4

request			: pip install requests

time			: pip install python-time

instagram_explore	: pip install instagram-explore

#######################EXECUTION OF PROJECT################################

step 1: cd <path to folder>
step 2: edit Scraper.py add your username at line 23 and password at line 25 and save the file
step 3: streamlit run gui.py
----------------------------------
		NOTE
----------------------------------
Need two instagram account and password
1. to collect data
2. to run the project
Before running the project after collecting the data you need to change username and password in Scraper.py (refer step 2)
